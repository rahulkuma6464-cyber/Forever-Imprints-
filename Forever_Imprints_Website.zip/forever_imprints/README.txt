FOREVER IMPRINTS - WEBSITE SETUP

1) OPEN THE WEBSITE ON YOUR PHONE/LAPTOP
- Extract this ZIP.
- Open index.html in Chrome.
- The design and form will work in DEMO mode.
- In demo mode, form entries are saved only in that browser/device.

2) MAKE CLIENT LEADS COME TO YOU PRIVATELY
The easiest free method is Google Sheets + Google Apps Script.

A. Create a Google Sheet called "Forever Imprints Leads".
Put these headers in row 1:
Timestamp | Name | Phone | Email | City | Design | Message

B. In the Sheet open Extensions > Apps Script.
Delete the sample code and paste:

const SHEET_NAME = "Sheet1";

function doPost(e) {
  const data = JSON.parse(e.postData.contents || "{}");
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  sheet.appendRow([
    new Date(),
    data.name || "",
    data.phone || "",
    data.email || "",
    data.city || "",
    data.design || "",
    data.message || ""
  ]);
  return ContentService
    .createTextOutput(JSON.stringify({ok:true}))
    .setMimeType(ContentService.MimeType.JSON);
}

C. Save the project.
D. Deploy > New deployment.
E. Select "Web app".
F. Execute as: Me.
G. Who has access: Anyone.
H. Deploy and copy the Web app URL.

Caution: This URL accepts form submissions. Do not publish your Google Sheet itself. Only the Web App URL goes into the website.

3) CONNECT THE FORM
Open index.html in a text/code editor.
Find:
const FORM_ENDPOINT = "PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE";

Replace the text inside the quotes with your Web App URL.
Save index.html.
Now every submitted lead will be added to your private Google Sheet.

4) PUT YOUR OWN FRAME DESIGNS
For a quick version, you can replace the sample cards in the HTML with image tags, e.g.
<img src="images/frame1.jpg" alt="Frame 1" style="width:100%;height:260px;object-fit:cover">

Create an "images" folder beside index.html and put your frame photos inside.

5) PUT IT ONLINE
You can upload the folder to any static hosting service that supports HTTPS.
For a beginner-friendly free option, use GitHub Pages:
- Create a GitHub account.
- Create a new public repository.
- Upload index.html and your images folder.
- Settings > Pages > Deploy from branch > main / root.
- GitHub will give you a website URL.

6) IMPORTANT
The website code does NOT collect or expose leads publicly by itself. The Google Sheet is the private storage. Keep your Google account secure and don't share the Sheet with clients.

If you want WhatsApp alerts too, connect a WhatsApp/automation service later; do not put private API keys directly in index.html.
